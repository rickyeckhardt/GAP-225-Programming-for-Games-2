#pragma once

class People {
protected:
    string m_firstName;
    string m_lastName;
    string m_phoneNumber;
    string m_homeAddress;
    string m_stateAbbr;
    string m_zipCode;

public:
    string getFirstName() { return m_firstName; }
    string getLastName() { return m_lastName; }
    string getPhoneNumber() { return m_phoneNumber; }
    string getHomeAddress() { return m_homeAddress; }
    string getStateAbbr() { return m_stateAbbr; }
    string getZipCode() { return m_zipCode; }
    // Returns a entire record of type Person. 
    string getPerson() { return m_firstName + "\t" + m_lastName + "\t" + m_phoneNumber + "\t" + m_stateAbbr + "\t" + m_zipCode; }

    void setFirstName(string fname) { m_firstName = fname; }
    void setLastName(string lname) { m_lastName = lname; }
    void setPhoneNumber(string phone) { m_phoneNumber = phone; }
    void setHomeAddress(string address) { m_homeAddress = address; }
    void setStateAbbr(string abbr) { m_stateAbbr = abbr; }
    void setZipCode(string zip) { m_zipCode = zip; }
};